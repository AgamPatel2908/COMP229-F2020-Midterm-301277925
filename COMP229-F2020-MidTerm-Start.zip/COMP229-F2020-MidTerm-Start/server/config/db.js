module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://agam940940:P@ssw0rd@books.ik7w1e2.mongodb.net/?retryWrites=true&w=majority"
};
